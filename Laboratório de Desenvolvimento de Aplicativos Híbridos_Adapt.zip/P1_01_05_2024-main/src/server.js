import app from './app';

app.listen(3000, () => {
  console.log('Ouvindo a porta 3000');
});
